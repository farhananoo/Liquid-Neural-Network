# Training models

Run training:

`python main.py model=baseline`

# Configuration

TODO: Describe this section