# Annotate data

Write annotation files for train, test and validation:

`python main.py`

Data should be already preprocessed.

# Configuration

TODO: Describe this section