from src.datasets.default_dataset import DefaultDataset
